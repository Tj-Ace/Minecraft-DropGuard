package com.tj.dropguard.mixin;

import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public abstract class KeyboardMixin {
    @Inject(method = "onKey", at = @At("HEAD"), cancellable = true)
    private void dropGuard$blockWorldDrop(long window, int action, class_11908 input, CallbackInfo ci) {
        if (action != GLFW.GLFW_PRESS) {
            return;
        }

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return;
        }

        if (!client.field_1690.field_1869.method_1417(input)) {
            return;
        }

        if (client.field_1755 != null) {
            return;
        }

        ci.cancel();
    }
}
